#!/usr/bin/env bash
# This file will contain functions related to gathering stats and displaying it for agent
# Agent will have to call mmp-stats.sh which will contain triggers for configuration files and etc.
# Do not add anything static in this file
GPU_COUNT=$1
LOG_FILE=$2
cd `dirname $0`
. mmp-external.conf

get_bus_ids() {
    local vendor_id="$1"
    local bus_ids=$(/bin/lspci -n | awk '$2 ~ /^0300|0302:/ && $3 ~ /^'"${vendor_id}"':/ {print $1}')
    local decimal_bus_ids=()

    if [ -z "$bus_ids" ]; then
        exit 1
    fi

    while read -r bus_id; do
        local decimal_bus_id=$((16#${bus_id%%:*}))
        decimal_bus_ids+=("$decimal_bus_id")
    done <<< "$bus_ids"

    echo "${decimal_bus_ids[*]}"
}

get_cards_hashes() {
    hash=''
    for (( i=0; i < ${GPU_COUNT}; i++ )); do
        hash[$i]=''

        local khs=$(cat "$LOG_FILE" |grep -oP "GPU${i}.*?\K\d+\.\d+"|tail -n1)
        if [[ -z "$khs" ]]; then
            local khs="0"
        fi
        if [[ ${khs} > 0 ]]; then
            hash[$i]=$(echo $khs)
        fi
    done
}

get_miner_shares_ac(){
    ac=0
    local ac=$(cat "$LOG_FILE" | grep "rqiner::gpu::pool" | tail -n1 | grep -oP "Solutions: \K\d+")
    if [[ -z "$ac" ]]; then
        local ac="0"
    fi
    echo $ac
}

get_miner_stats() {
    stats=
    local hash=
    get_cards_hashes                        # hashes array
    nv_bus_ids=$(get_bus_ids "10de")
    local busid=("${nv_bus_ids[@]}")
    local units='hs'                    # hashes units
    # A/R shares by pool
    local ac=$(get_miner_shares_ac)

    stats=$(jq -nc \
            --argjson hash "$(echo ${hash[@]} | tr " " "\n" | jq -cs '.')" \
            --argjson busid "$(echo ${busid[@]} | tr " " "\n" | jq -cs '.')" \
            --arg units "$units" \
            --arg ac "$ac" --arg inv "0" --arg rj "0" \
            --arg miner_version "$EXTERNAL_VERSION" \
            --arg miner_name "$EXTERNAL_NAME" \
        '{$busid, $hash, $units, air: [$ac, $inv, $rj], miner_name: $miner_name, miner_version: $miner_version}')
    # total hashrate in hs
    echo $stats
}
get_miner_stats $GPU_COUNT $LOG_FILE
